.. note::

  CMake reserves identifiers that:

  * begin with ``CMAKE_`` (upper-, lower-, or mixed-case), or
  * begin with ``_CMAKE_`` (upper-, lower-, or mixed-case), or
  * begin with ``_`` followed by the name of any :manual:`CMake Command <cmake-commands(7)>`.
