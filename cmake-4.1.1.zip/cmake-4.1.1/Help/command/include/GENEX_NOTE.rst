.. |more_see_also| replace:: See the :manual:`cmake-buildsystem(7)` manual
   for more on defining buildsystem properties.

Arguments to |command_name| may use generator expressions
with the syntax ``$<...>``. See the :manual:`cmake-generator-expressions(7)`
manual for available expressions.  |more_see_also|
